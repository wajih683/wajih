# 0. INSTALLATION DES PACKAGES (à faire une seule fois)
install.packages(c("data.table", "dplyr", "factoextra", "klaR",
                   "caret", "rpart", "ranger", "pROC"))
install.packages("rpart.plot")

# 1. CHARGEMENT DES LIBRAIRIES
library(data.table)    # fread rapide
library(dplyr)         # manipulation
library(factoextra)    # visualisation K-means
library(klaR)          # kmodes
library(caret)         # train/test split, metrics
library(rpart)         # arbre de décision
library(rpart.plot)    # plot rpart
library(ranger)        # random forest rapide
library(pROC)          # courbe ROC
library(ggplot2)       # graphes
# 2. IMPORTATION – on ne lit que les colonnes utiles
cols_keep <- c(
  "lead_time", "adr", "stays_in_week_nights", "stays_in_weekend_nights",
  "hotel", "arrival_date_month", "meal", "market_segment", "is_canceled"
)

hotel_dt <- fread("hotel.csv",
                  sep = ";",
                  select = cols_keep,
                  showProgress = TRUE)

hotel_df <- as.data.frame(hotel_dt)
# 3. ÉCHANTILLONNAGE POUR CLUSTERING (20 000 lignes)
set.seed(123)
sample_idx <- sample(nrow(hotel_df), 20000)
sample_km   <- hotel_df[sample_idx, ]
# 4. CLUSTERING K-MEANS (numérique)
num_data   <- sample_km %>% select_if(is.numeric) %>% na.omit()
scaled_num <- scale(num_data)
# 4.1 Déterminer k via la méthode du coude
fviz_nbclust(scaled_num, kmeans, method = "wss") +
  ggtitle("Méthode du coude – K-means")
# 4.2 Appliquer K-means (k = 3 en exemple)
set.seed(123)
k <- 3
km_res <- kmeans(scaled_num, centers = k, nstart = 25)
# 4.3 Stocker les labels dans sample_km
sample_km$km_cluster <- factor(km_res$cluster)
# 4.4 Visualisation des clusters
fviz_cluster(km_res, data = scaled_num,
             ellipse.type = "norm",
             main = "Clusters K-means")
# 5. CLUSTERING K-MODES (catégoriel)
cat_data <- sample_km %>%
  select_if(is.character) %>%
  mutate_if(is.character, as.factor)
set.seed(123)
kmodes_res <- kmodes(cat_data, modes = k, iter.max = 20)

sample_km$kmodes_cluster <- factor(kmodes_res$cluster)
# 5.1 Aperçu de la répartition
print(table(sample_km$kmodes_cluster))
# 5.2 Visualisation K-modes: distribution du type d'hôtel
library(ggplot2)

ggplot(sample_km, aes(x = hotel, fill = kmodes_cluster)) +
  geom_bar(position = "fill") +
  labs(
    title = "Distribution du type d'hôtel par cluster K-modes",
    x = "Type d'hôtel",
    y = "Proportion",
    fill = "Cluster"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
# 6. PRÉPARATION POUR CLASSIFICATION
#    On travaille sur sample_km qui contient déjà km_cluster + kmodes_cluster
df_clf <- sample_km %>%
  mutate(is_canceled = as.factor(is_canceled))
# 7. TRAIN/TEST SPLIT (70/30)
set.seed(456)
idx   <- createDataPartition(df_clf$is_canceled, p = 0.7, list = FALSE)
train <- df_clf[idx, ]
test  <- df_clf[-idx, ]
# 8. MODELE 1 : Arbre de décision
model_tree <- rpart(is_canceled ~ ., data = train, method = "class")
# 8.1 Visualisation de l'arbre
rpart.plot(
  model_tree,
  type   = 2,
  extra  = 104,
  fallen.leaves = TRUE,
  shadow.col    = "gray"
)
# 8.2 Évaluation
pred_tree  <- predict(model_tree, test, type = "class")
cm_tree    <- confusionMatrix(pred_tree, test$is_canceled)
print(cm_tree)
# 9. MODELE 2 : Random Forest via ranger
model_ranger <- ranger(is_canceled ~ ., data = train, probability = TRUE,importance = "impurity")
# 9.1 Extraction d'un arbre de la forêt (optionnel)
imp_df <- as.data.frame(model_ranger$variable.importance)
imp_df$varname <- rownames(imp_df)
names(imp_df)[1] <- "importance"

# Barplot avec ggplot2
ggplot(imp_df, aes(x = reorder(varname, importance), y = importance)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  labs(
    title = "Importance des variables – Random Forest",
    x = "Variable",
    y = "Importance"
  )

pred_prob  <- predict(model_ranger, test)$predictions[,2]
pred_class <- factor(ifelse(pred_prob > 0.5, "1", "0"))
cm_ranger  <- confusionMatrix(pred_class, test$is_canceled)
print(cm_ranger)
# 10. ÉVALUATION COMPLÉMENTAIRE – Courbe ROC & AUC
roc_obj <- roc(test$is_canceled, pred_prob)
plot(roc_obj, main = "ROC – Random Forest (ranger)")
cat("AUC =", round(auc(roc_obj), 3), "\n")



